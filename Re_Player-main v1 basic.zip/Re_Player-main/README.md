# Re_Player
Re-Player is a sleek offline audio player with visualizer, EQ presets, and a modern theme toggle. Built as a PWA, it lets you play local music files, view recent tracks, and enjoy customizable sound, even without internet access.
